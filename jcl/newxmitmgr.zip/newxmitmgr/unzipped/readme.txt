UnZipped directory
------------------

this is the deafult directory that will be used to store any files that are unzipped
by xmit manager.

You can specify your own directory in the Network options screen but it is advisable
to use the default.